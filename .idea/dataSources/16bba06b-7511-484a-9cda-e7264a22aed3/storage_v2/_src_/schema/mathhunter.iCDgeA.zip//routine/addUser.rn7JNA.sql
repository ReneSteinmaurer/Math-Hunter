create
    definer = root@localhost procedure addUser(IN usernameIn varchar(100), IN passwordIn varchar(100),
                                               IN playerNameIn varchar(100))
begin
    declare playerIDVar int;
    declare userNamevar varchar(100);
    select name from users where name = usernameIn into userNamevar;
    if (userNamevar is null) then
        insert into users (name, password) values (usernameIn, passwordIn);
        insert into players (name, points) values (playerNameIn, 10);
        select id from players where playerNameIn = name into playerIDVar;
        insert into user_player (playerID, userName, playerName) values (playerIDVar, usernameIn, playerNameIn);
    end if;
end;

