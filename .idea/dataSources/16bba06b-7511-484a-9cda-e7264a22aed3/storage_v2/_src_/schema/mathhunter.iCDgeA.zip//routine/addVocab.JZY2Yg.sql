create
    definer = root@localhost procedure addVocab(IN germanVocabIn varchar(100), IN englischVocabIn varchar(100))
begin
    declare existsVocab int(50);
    select germanVocab from vocabs where germanVocab = germanVocabIn into existsVocab;
    if (existsVocab is null) then
       insert into vocabs (germanVocab, englischVocab)
       values (germanVocabIn, englischVocabIn);
    end if;
end;

